import pygame, os, pickle
from random import randint


class Settings:
    """ Global game settings class"""
    
    def __init__(self):
   
        # Screen resolution
        self.flags = pygame.SCALED | pygame.FULLSCREEN
        self.screen_width = 720
        self.screen_heigth = 480

        self.game_paused = False
       
        # end_game bonus
        self.bonus = 100000
        
        # Font color
        self.text_col = ('white') 
        
        ## Initialize score and hiscore variables
        self.hiscore_file = "hiscore.pkl"
        # standard hiscore
        self.current_hiscore = {1: ['PNF', 150000], 2: ['AFF', 120000], 3: ['ANF', 80000], 4: ['PHF', 50000], 5: ['LMP', 30000], 
                                6: ['ALE', 20000], 7: ['OZY', 15000], 8: ['AMP', 10000], 9: ['LRP', 5000], 10: ['RBH', 1000]}
        self.new_hiscore = {}
        # standard hiscore name if none
        self.name = 'INV'
        self.hi_score = 0
        self.hiscore_list = []
            
        # Initialize stars variables
        self.x = self.y = 0
        self.num_stars = 200# numbers of stars on screen

        # animation settings
        self.last_update = pygame.time.get_ticks()
        self.animation_cooldown = 20
        self.frame = 0
        self.x = 0
        self.y = 0

        
        # turn on/off ship thruster
        self.ship_thruster_on = False
        self.ship_thruster_off = False
        
        # activate last thrust (end game)
        self.ship_last_thrust = False

        # Obstacle setup
        self.block_size = int(6 * 0.6)
        self.obstacle_amount = 4
        self.obstacle_color = ('#FF5F1F') 
        self.obstacle_x_start = int(self.screen_width / 12)
        self.obstacle_y_start = self.screen_heigth - 90
        # Calculate obstacles positions on screen and put in a list
        self.obstacle_x_positions = []
        for num in range(self.obstacle_amount):
           self.obstacle_x_positions.append(num * (self.screen_width / self.obstacle_amount))
        

        # Player settings
        self.player_speed = 3
        self.laser_speed = 9

    
        # Aliens settings
        self.alien_speedup_scale = 1.04
        self.alien_laser_y = 9
        self.alien_direction = 1
        self.alien_distance = 7 # distance that a line of aliens descends 
        self.alien_time_between_bullets = 900
        self.alien_rows = 5 #5
        self.alien_cols = 11 #11
        self.alien_x_distance = 42  
        self.alien_y_distance = 29
        self.aliens_x_offset = 42  
        self.aliens_y_offset = 60
   
        # Extra alien settings
        self.range_a = 800
        self.range_b = 1600
        self.extra_spawn_time = randint (self.range_a, self.range_b)
        self.extra_speed = 1.8
        self.extra_list_points = [100, 200, 500, 800, 1000]
        self.extra_point = 0

              
        self.initialize_dynamic_settings()

    def load_hiscore(self):
        if os.path.exists(self.hiscore_file):
            with open (self.hiscore_file, "rb") as file:
                try:
                    self.current_hiscore = pickle.load(file)
                except Exception:
                    self.current_hiscore={}
        if self.current_hiscore:
            if len(self.current_hiscore) > 10:
                self.current_hiscore.popitem()
            self.hiscore_list = list(self.current_hiscore.values())
            self.hi_score = self.hiscore_list[0][1]
        else:
            self.hi_score = 0

   
    def initialize_dynamic_settings(self):
        
        self.title_active = True
        # load hiscore file
        self.load_hiscore()
        # Initialize level and lives variables
        self.level = 0
        self.lives = 2
        self.score = 0
        # player ship
        self.shoots_allowed = 1
        self.thruster_time = 5
        # alien fleet
        self.alien_speed = 0.78 
        self.alien_bullets_allowed = 1
        self.alien_laser_speed = 3
        # extra alien settings
        self.extra_shoot_interval = 1000
        self.last_extra_shoot = pygame.time.get_ticks()
        self.activate_extra_shot = False
        self.extra_bullets_allowed = 1
        self.extra_laser_speed = 2.4
        
        # boss settings
        self.boss_shoot_interval = 600
        self.last_boss_shoot = pygame.time.get_ticks()
        self.boss_speed = 3
        self.boss_direction = 1
        self.boss_bullets_speed = 6
        self.boss_bullets_allowed = 1
        self.boss_hits = 0
        self.boss_total_hits = 10 #10
        self.boss_speedup_scale = 0.5
        self.start_boss_update = False
        self.executed_boss_animation = False
        self.boss_executed = False
       
        # flag for moving start or not
        self.moving_stars = False
        # flag for colors stars on title menu
        self.menu_stars = True
        # create a list for explosions time
        self.active_explosions = []   
        # Flags for the new_life function on the main program
        self.executed_2 = False
        self.executed_3 = False
        self.executed_4 = False
        self.activate_bonus = False
        self.executed_bonus = False
        # flag for unlock the player input to continue after show the game final screen        
        self.unlock_input = False
        self.double_shoot_warning = True
        self.boss_warning = True
        self.played_once = False
        self.wait = 0
        self.wait_2 = 0
       
        