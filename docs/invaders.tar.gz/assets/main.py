import pygame,sys, os, pickle, asyncio, platform
from random import choice, randint
from player import Player
from crt import CRT
from settings import Settings
from alien import Alien, Extra, Boss
from alien_laser import AlienLaser, ExtraLaser, BossLaser
from laser import Laser
from menu import *
import scenary
from scenary import Planet
from spritesheets import SpriteSheet

class Game:
    """ Principal class of Invaders game"""
    def __init__(self):

        self.s = Settings()
        self.clock = pygame.time.Clock()
        
        # initialize screen
        self.screen =  pygame.display.set_mode((self.s.screen_width, self.s.screen_heigth))
        pygame.display.set_caption("Attack on Solar System")
        self.screen_rect = self.screen.get_rect()


        # Lifes indicator on top right screen
        self.life_surf_original = pygame.image.load(self.resource_path('assets/graphics/player.png')).convert_alpha()
        self.life_surf = pygame.transform.scale_by(self.life_surf_original, 0.8)
        self.live_x_start_pos = self.s.screen_width - (self.life_surf.get_size()[0] * 2.3 + 55)
        self.life_x = self.live_x_start_pos + ((self.life_surf.get_size()[0]))  

        # Title points animation spritesheet
        self.title_points = []
        self.points_spritesheet = SpriteSheet('assets/graphics/spritesheets/points/points.png', self)
        for x in range (0, 19):
            self.title_points.append(self.points_spritesheet.parse_sprite(f'points{x}.png'))
       
        # Load explosions images
        self.explosion_alien = pygame.image.load(self.resource_path('assets/graphics/alien_explosion.png')).convert_alpha() 
        self.explosion_extra = pygame.image.load(self.resource_path('assets/graphics/extra_explosion.png')).convert_alpha()
        self.explosion_boss = pygame.image.load(self.resource_path('assets/graphics/boss_explosion/sprite_0.png')).convert_alpha()
        self.laser_hit = pygame.image.load(self.resource_path('assets/graphics/laser_hit.png')).convert_alpha()
        self.explosion_player = pygame.image.load(self.resource_path('assets/graphics/player_explosion.png')).convert_alpha()
        self.block_hit = pygame.image.load(self.resource_path('assets/graphics/block_hit.png')).convert_alpha()
        self.laser_miss = pygame.image.load(self.resource_path('assets/graphics/laser_miss.png')).convert_alpha()
        self.boss_loss_sprites =[]
        self.boss_loss_sprites.append (pygame.image.load(self.resource_path('assets/graphics/boss_explosion/sprite_0.png')).convert_alpha())
        self.boss_loss_sprites.append (pygame.image.load(self.resource_path('assets/graphics/boss_explosion/sprite_1.png')).convert_alpha())
        self.boss_loss_sprites.append (pygame.image.load(self.resource_path('assets/graphics/boss_explosion/sprite_2.png')).convert_alpha())
        self.boss_loss_sprites.append (pygame.image.load(self.resource_path('assets/graphics/boss_explosion/sprite_3.png')).convert_alpha())
        self.current_boss_loss_sprite = 0


        # Load pause image
        self.pause_keys = pygame.image.load(self.resource_path('assets/graphics/pause_keys.png')).convert_alpha()
        self.pause_keys_rect = self.pause_keys.get_rect(midtop = (self.s.screen_width /2, self.s.screen_heigth /3))
       
        # Create Font objects from files
        self.font_title = pygame.font.Font(self.resource_path('assets/font/Pixelzone.ttf'), 72)
        self.font_credits = pygame.font.Font(self.resource_path('assets/font/Pixelzone.ttf'), 24)
        self.font_copyright = pygame.font.Font(self.resource_path('assets/font/Pixelzone.ttf'), 20)
        self.font_scoreboard = pygame.font.Font(self.resource_path('assets/font/Pixeled.ttf'), 10) #GradientVector.otf
        self.font_points = pygame.font.Font(self.resource_path('assets/font/Pixeled.ttf'), 10)
        self.font_planets = pygame.font.Font(self.resource_path('assets/font/Y224-2vdae.ttf'), 36)
        self.font_display = pygame.font.Font(self.resource_path('assets/font/Pixeled.ttf'), 18)
        self.font_game_over = pygame.font.Font(self.resource_path('assets/font/Pixeled.ttf'), 48)
        self.font_initials = pygame.font.Font(self.resource_path('assets/font/Y224-2vdae.ttf'), 42)
        self.font_hiscore = pygame.font.Font(self.resource_path('assets/font/Y224-2vdae.ttf'), 20) 
        self.font_end_game = pygame.font.Font(self.resource_path('assets/font/Y224-2vdae.ttf'), 14)

        # Load sounds file
        self.laser_sound = pygame.mixer.Sound(self.resource_path('assets/audio/shoot.ogg'))
        self.alien_laser_sound = pygame.mixer.Sound(self.resource_path('assets/audio/alien_laser.ogg'))
        self.extra_alien_sound = pygame.mixer.Sound(self.resource_path('assets/audio/extra_sound.ogg'))
        self.extra_laser_sound = pygame.mixer.Sound(self.resource_path('assets/audio/extra_laser.ogg'))
        self.new_life_sound = pygame.mixer.Sound(self.resource_path('assets/audio/life.ogg'))
        self.explosion_sound = pygame.mixer.Sound(self.resource_path('assets/audio/explosion.ogg'))
        self.player_explosion_sound = pygame.mixer.Sound(self.resource_path('assets/audio/player_explosion.ogg'))
        self.extra_explosion_sound = pygame.mixer.Sound(self.resource_path('assets/audio/extra_explosion.ogg'))
        self.block_rebuild_sound = pygame.mixer.Sound(self.resource_path('assets/audio/block_rebuild.ogg'))
        self.shot_collision = pygame.mixer.Sound(self.resource_path('assets/audio/shot_collision.ogg'))
        self.obstacle_explosion = pygame.mixer.Sound(self.resource_path('assets/audio/obstacle_explosion.ogg'))
        self.alien_fleet_sound = pygame.mixer.Sound(self.resource_path('assets/audio/alien_fleet.ogg'))
        self.ship_thruster_sound = pygame.mixer.Sound(self.resource_path('assets/audio/ship_thruster.ogg'))
        self.name_entry_sound = pygame.mixer.Sound(self.resource_path('assets/audio/name_entry.ogg'))
        self.bonus_sound = pygame.mixer.Sound(self.resource_path('assets/audio/bonus.ogg'))
        self.game_over_sound = pygame.mixer.Sound(self.resource_path('assets/audio/game_over.ogg'))
        self.first_place_sound = pygame.mixer.Sound(self.resource_path('assets/audio/first_place.ogg'))
        self.warning_sound = pygame.mixer.Sound(self.resource_path('assets/audio/warning.ogg'))
        self.danger_sound = pygame.mixer.Sound(self.resource_path('assets/audio/danger.ogg'))
        self.boss_loss_sound = pygame.mixer.Sound(self.resource_path('assets/audio/boss_loss.ogg'))
        self.boss_music = pygame.mixer.Sound(self.resource_path('assets/audio/battle_boss.ogg'))
        self.end_game_music = pygame.mixer.Sound(self.resource_path('assets/audio/end_game.ogg'))
        

        # Set volume
        self.end_game_music.set_volume(0.8)
        self.boss_music.set_volume(0.5)
        self.boss_loss_sound.set_volume(0.8)
        self.danger_sound.set_volume(0.8)
        self.warning_sound.set_volume(0.8)
        self.game_over_sound.set_volume(0.4)
        self.bonus_sound.set_volume(0.3)
        self.name_entry_sound.set_volume(0.3)
        self.ship_thruster_sound.set_volume(0.3)
        self.alien_fleet_sound.set_volume(0.8)
        self.laser_sound.set_volume(0.2)
        self.alien_laser_sound.set_volume(0.2)
        self.extra_alien_sound.set_volume(0.1)
        self.extra_laser_sound.set_volume(0.2)
        self.new_life_sound.set_volume(0.3)
        self.explosion_sound.set_volume(0.2)
        self.player_explosion_sound.set_volume(0.2)
        self.extra_explosion_sound.set_volume(0.3)
        self.block_rebuild_sound.set_volume(0.2)
        self.obstacle_explosion.set_volume(0.2)
        self.shot_collision.set_volume(0.2)
       

        ## Create instances
        self.crt = CRT(self)
        self.main_menu = Menu(self)
        self.game_over_menu = GameOver(self)
        self.hiscore_menu = Hiscore(self)
        self.beatgame_menu = BeatGame(self)
        self.shape = scenary.shape
       
        # sprites
        self.planet = Planet(self)
        self.alien = Alien('red',0,0, self)
        self.extra_sprite = Extra('left', self)
        self.player_sprite = Player(self)
        self.boss_sprite = Boss(self)
        self.boss_laser_sprite = BossLaser((0,0), self)
       
        # sprite groups
        self.planets = pygame.sprite.Group(self.planet)
        self.player = pygame.sprite.GroupSingle(self.player_sprite)
        self.extra = pygame.sprite.GroupSingle()
        self.aliens = pygame.sprite.Group()
        self.blocks = pygame.sprite.Group()
        self.alien_lasers = pygame.sprite.Group()
        self.extra_lasers = pygame.sprite.Group()
        self.boss_lasers = pygame.sprite.Group()
        self.lasers = pygame.sprite.Group()
        self.stars = pygame.sprite.Group()
        self.boss = pygame.sprite.GroupSingle()


        """ initialize variables """
        # Menu inicial
        self.curr_menu = self.main_menu
        self.running = True

        # flag for level up fucntion
        self.level_up_active = False  

        ## PAUSE FUNCTION
        # time variable for pause function 
        self.time =  0
        # initial time variable for pause function 
        self.initial_time = 0
        # flag variable for pause function
        self.start = False

        self.blink_time = 0
        ## SHIP BOOST TIME FUNCTION
        # time variable for ship boost function 
        self.ship_time =  0
        # initial time variable for boost ship 
        self.ship_initial_time = 0
        self.start_boost = False
        
        ## OBSTACLE 
        # flag variable for rebuild obstacles blocks
        self.block_rebuild = False
        # increment variable used on redraw blocks function
        self.block_count = 0
        
        ## Planets animation 
        # Flag for start/stop planet animation
        self.finish_planet_animation = False
        # variable used on leave_planet_animation function
        self.i = 0
        
        ## Start game flags
        # Flag for start the game
        #self.s.running = True
        # Flag for start/ stop the game_loop function
        self.playing = False
        
        # explosion time function variable
        self.dt = 0   

        self.count_dots = 0
        # Call functions for create stars
        self.create_stars(self.s.x, self.s.y)

       
    """ GAME FUNCTIONS """

    def resource_path(self,relative_path):
        """ Returns the correct path to the file, working in both the code and the executable. """
        if hasattr(sys, '_MEIPASS'):
            return os.path.join(sys._MEIPASS, relative_path)
        return os.path.join(os.path.abspath("."), relative_path)


    def create_stars(self, x, y):
        """ Create space stars """
        for value in range(self.s.num_stars):
            self.red = randint(0, 255)
            self.green = randint(0, 255)
            self.blue = randint(0, 255)
            rand_x = randint(0, self.s.screen_width)
            rand_y =  randint (0, self.s.screen_heigth)
            if x == rand_x:
                rand_x = randint(0, self.s.screen_width)
            if y == rand_y:
                rand_y = randint(0, self.s.screen_heigth)
            x = rand_x
            y = rand_y
            self.star_sprite = scenary.Stars((self.red, self.green, self.blue), x, y, self)
            self.stars.add(self.star_sprite)



    def create_obstacle(self, offset_x):
        """Create obstacles sprites (player shields) 
        Parameters: 
        offset_x (int): space between obstacles 
        """
        for row_index, row in enumerate(self.shape):
            for col_index, col in enumerate(row):
                if col == 'x':
                    x = self.s.obstacle_x_start + col_index * self.s.block_size + offset_x
                    y = self.s.obstacle_y_start + row_index * self.s.block_size        
                    self.block = scenary.Block(self.s.block_size, self.s.obstacle_color, x, y)
                    self.blocks.add(self.block)
                         
   
    def create_multiple_obstacles(self):
        """Create multiples obstacles defined on obstacle_x_positions list"""
        for offset_x in self.s.obstacle_x_positions:
            self.create_obstacle(offset_x)
                        
    
    def alien_setup(self):
        """Create the aliens fleet"""
        for row_index, row in enumerate(range(self.s.alien_rows)):
            for col_index, col in enumerate(range(self.s.alien_cols)):
                x = col_index * self.s.alien_x_distance + self.s.aliens_x_offset
                y = row_index * self.s.alien_y_distance + self.s.aliens_y_offset
                
                if row_index == 0: alien_sprite = Alien('yellow', x, y, self)
                elif 1 <= row_index <=2: alien_sprite = Alien('green', x, y, self)
                else: alien_sprite = Alien('red', x, y, self)
                self.aliens.add(alien_sprite)    
           
    def alien_position_checker(self):
        """Check if the alien fleet had reach the side edge of the screen"""
        for alien in self.aliens:
            if alien.rect.right >= self.s.screen_width or alien.rect.left <= 0:
                self.alien_move_down()
                break

    def alien_move_down(self):
        """Move down the alien fleet when they reach the side edge of screen
        and force to the oposite direction"""
        if self.aliens:
            for alien in self.aliens:
                alien.rect.y += self.s.alien_distance
            lowest_alien_sprite = max (self.aliens, key=lambda a: a.rect.bottom)
            pos_y = lowest_alien_sprite.rect.bottom
            
            if pos_y >= self.s.screen_heigth - self.player_sprite.image.get_width():
                self.s.lives = -1
            else: 
                self.s.alien_direction *= -1 
               
    
    def alien_shoot(self):
        """ Create the aliens shoot"""
        if self.aliens:
            random_alien = choice(self.aliens.sprites())
            if len (self.alien_lasers) < self.s.alien_bullets_allowed:
                laser_sprite = AlienLaser (random_alien.rect.midbottom, self)
                self.alien_lasers.add(laser_sprite)
                self.alien_laser_sound.play()

    def extra_shoot(self):
        """ Create the aliens shoot"""
        if self.s.activate_extra_shot:
            if self.extra:
                current_sprite = self.extra.sprites()[0]
                if len (self.extra_lasers) < self.s.extra_bullets_allowed:
                    extra_laser_sprite = ExtraLaser (current_sprite.rect.midbottom, self)
                    self.extra_lasers.add(extra_laser_sprite)
                    self.extra_laser_sound.play()
    
    def boss_shoot(self):
        """ Create the aliens shoot"""
        if self.boss:
            current_sprite = self.boss.sprites()[0]
            if len (self.boss_lasers) < self.s.boss_bullets_allowed:
                boss_laser_sprite = BossLaser (current_sprite.rect.midbottom, self)
                self.boss_lasers.add(boss_laser_sprite)
                self.extra_laser_sound.play()
                    

    def extra_alien_timer (self):
        """Spawns an extra alien as soon as the cooldown ends"""
        if self.extra_sprite.execute == True:
            self.s.extra_spawn_time -= 1
            if self.s.extra_spawn_time <= 0:
                self.extra.add(Extra(choice(['right','left']), self))
                self.extra_alien_sound.play()
                self.s.extra_spawn_time = randint (self.s.range_a, self.s.range_b)
            

    def explosion_time(self):   
        """Duration of the explosions shown on the screen"""     
        for exp in self.s.active_explosions[:]:  
            exp["time"] -= self.dt
            if exp["time"] <= 0:
                self.s.active_explosions.remove(exp)

    
    def draw_explosion(self):
        """Draws images of the explosions on the screen if there are any in the list"""
        for exp in self.s.active_explosions:
            match exp['hit']:
                case 'extra_explosion':
                    self.screen.blit(self.explosion_extra,  exp["pos"])
                case 'boss_hit':
                    self.screen.blit(self.explosion_extra,  exp["pos"])
                case 'boss_explosion':
                    self.current_boss_loss_sprite += 0.2
                    if self.current_boss_loss_sprite >= len (self.boss_loss_sprites):
                        self.current_boss_loss_sprite = 0
                        break
                    self.screen.blit(self.boss_loss_sprites[int(self.current_boss_loss_sprite)],  exp["pos"])
                case 'extra':
                    self.draw_text(f"{exp['points']}",  self.font_points, 'red', exp['pos'][0] + 20, exp['pos'][1] + 15)
                case 'laser':
                    self.screen.blit(self.laser_hit, exp["pos"])
                case 'alien':
                    self.screen.blit(self.explosion_alien,  exp["pos"])                                 
                case 'player':
                    self.screen.blit(self.explosion_player, exp["pos"])
                    self.lasers.empty()
                    if exp["time"] <= 90:
                        self.player.add(self.player_sprite)
                        self.player_sprite.restart_player_location()
                case 'block':
                    self.screen.blit(self.block_hit, exp["pos"])
                case 'laser_miss':
                    self.screen.blit(self.laser_miss, exp["pos"])
                case 'fleet_bottom':
                    self.screen.blit(self.explosion_player, exp["pos"])
                    self.s.lives = -1

                case 'earth':
                    self.draw_text(f'DEFEND EARTH',  self.font_planets, '#E1E6E7', exp['pos'][0], exp['pos'][1])
                case 'moon':
                    self.draw_text(f'DEFEND MOON',  self.font_planets, '#E1E6E7', exp['pos'][0], exp['pos'][1])
                case 'mars':
                    self.draw_text(f'DEFEND MARS',  self.font_planets, '#E1E6E7', exp['pos'][0], exp['pos'][1])
                case 'jupiter':
                    self.draw_text(f'DEFEND JUPITER',  self.font_planets, '#E1E6E7', exp['pos'][0], exp['pos'][1])
                case 'saturn':
                    self.draw_text(f'DEFEND SATURN',  self.font_planets, '#E1E6E7', exp['pos'][0], exp['pos'][1])
                case 'uranus':
                    self.draw_text(f'DEFEND URANUS',  self.font_planets, '#E1E6E7', exp['pos'][0], exp['pos'][1])
                case 'netuno':
                    self.draw_text(f'DEFEND NEPTUNE',  self.font_planets, '#E1E6E7', exp['pos'][0], exp['pos'][1])
                case 'double_shoot':
                    if not self.s.played_once:
                        self.warning_sound.play()
                        self.s.played_once = True
                    self.draw_text(f'DOUBLE SHOOT',  self.font_display, '#00ff00', exp['pos'][0], exp['pos'][1])
                case 'new_life':
                    self.draw_text(f'NEW LIFE',  self.font_display, '#fff01f', exp['pos'][0], exp['pos'][1])
                case 'warning':
                    self.blink_text()
                    if self.blink_time > 1:
                        self.draw_text(f'WARNING',  self.font_display, 'red', exp['pos'][0], exp['pos'][1]) 

    
    def player_laser_collision (self):
        for laser in self.lasers:
            # Obstacle 
            if pygame.sprite.spritecollide(laser, self.blocks, True):
                laser.kill()                 
            # Alien 
            aliens_hit = pygame.sprite.spritecollide(laser, self.aliens, True)
            if aliens_hit:
                for alien in aliens_hit:
                    self.s.active_explosions.append({"pos" : (alien.rect.x, alien.rect.y), "time" : 100, "hit" : "alien"})                       
                    self.s.score += alien.value 
                laser.kill()
                self.explosion_sound.play()
                self.s.alien_speed *= self.s.alien_speedup_scale                
            # Extra alien
            extra_hit = pygame.sprite.spritecollide(laser, self.extra, True)
            if extra_hit:
                for extra in extra_hit:
                    self.s.extra_point = choice (self.s.extra_list_points)
                    self.s.active_explosions.append({"pos" : (extra.rect.x, extra.rect.y), "time" : 300, "hit" : "extra_explosion"})
                    self.s.active_explosions.append({"pos" : (extra.rect.x, extra.rect.y), "time" : 1300, "hit" : "extra", "points" : self.s.extra_point})
                    self.extra_explosion_sound.play()
                    self.extra_alien_sound.stop()
                    self.s.score += self.s.extra_point
                laser.kill()
            # Boss alien 
            boss_hit = pygame.sprite.spritecollideany(laser, self.boss)
            if boss_hit:
                self.s.active_explosions.append({"pos" : (laser.rect.x, laser.rect.y), "time" : 100, "hit" : "boss_hit"})
                self.s.boss_hits += 1
                if self.s.boss_hits == self.s.boss_total_hits:
                    self.boss_music.stop()
                    self.boss_loss_sound.play()
                    self.boss.empty()
                    self.s.active_explosions.append({"pos" : (self.boss_sprite.rect.x, self.boss_sprite.rect.y), "time" : 600, "hit" : "boss_explosion"})
                    self.s.boss_hits = 0
                laser.kill()
                self.explosion_sound.play()
            # Boss laser
            boss_laser_hit = pygame.sprite.spritecollide(laser, self.boss_lasers, False)
            if boss_laser_hit:
                self.s.active_explosions.append({"pos" : (laser.rect.x, laser.rect.y), "time" : 100, "hit" : "laser"})
                self.shot_collision.play()
                laser.kill()
            # Alien laser 
            laser_hit = pygame.sprite.spritecollide(laser, self.alien_lasers, True)
            if laser_hit:
                self.s.active_explosions.append({"pos" : (laser.rect.x, laser.rect.y), "time" : 100, "hit" : "laser"})
                self.shot_collision.play()
                laser.kill()
            # Extra laser
            extra_laser_hit = pygame.sprite.spritecollide(laser, self.extra_lasers, True)
            if extra_laser_hit:
                self.s.active_explosions.append({"pos" : (laser.rect.x, laser.rect.y), "time" : 100, "hit" : "laser"})
                self.shot_collision.play()
                self.extra_laser_sound.stop()
                laser.kill()

    def alien_laser_collision (self):
        for laser in self.alien_lasers:
            # Player 
            if pygame.sprite.spritecollide(laser, self.player, True):
                self.player_explosion_sound.play()
                self.s.lives -= 1
                self.alien_lasers.empty()
                self.s.active_explosions.append({"pos" : (self.player_sprite.rect.x, self.player_sprite.rect.y), "time" : 500, "hit" : "player"})                                  
            # Blocks 
            if pygame.sprite.spritecollide (laser, self.blocks, True):
                self.s.active_explosions.append({"pos" : (laser.rect.x, laser.rect.y), "time" : 500, "hit" : "block"})
                self.obstacle_explosion.play()
                laser.kill()

    def extra_laser_collision (self):
        for laser in self.extra_lasers:
            # Player 
            if pygame.sprite.spritecollide(laser, self.player, True):
                self.player_explosion_sound.play()
                self.s.lives -= 1
                self.extra_lasers.empty()
                self.s.active_explosions.append({"pos" : (self.player_sprite.rect.x, self.player_sprite.rect.y), "time" : 500, "hit" : "player"})                                          
            # Blocks 
            if pygame.sprite.spritecollide (laser, self.blocks, True):
                self.s.active_explosions.append({"pos" : (laser.rect.x, laser.rect.y), "time" : 500, "hit" : "block"})
                self.obstacle_explosion.play()
                laser.kill()
    
    def boss_laser_collision (self):
        # Player 
        if pygame.sprite.groupcollide(self.boss_lasers, self.player, True, True):
            self.player_explosion_sound.play()
            self.s.lives -= 1
            self.s.active_explosions.append({"pos" : (self.player_sprite.rect.x, self.player_sprite.rect.y), "time" : 500, "hit" : "player"})                                                     
        # Blocks 
        block_hit = pygame.sprite.groupcollide (self.boss_lasers, self.blocks, True, True)
        for block in block_hit:
            self.s.active_explosions.append({"pos" : (block.rect.x, block.rect.y), "time" : 500, "hit" : "block"})
            self.obstacle_explosion.play()
           
    def alien_collision (self):
        # Blocks
        block_hit = pygame.sprite.groupcollide(self.blocks, self.aliens, True, False)
        for block in block_hit:
            self.s.active_explosions.append({"pos" : (block.rect.x, block.rect.y), "time" : 500, "hit" : "block"})
            self.obstacle_explosion.play()
        # Player
        if pygame.sprite.groupcollide(self.player, self.aliens, True, True):
            self.player_explosion_sound.play()
            self.s.active_explosions.append({"pos" : (self.player_sprite.rect.x, self.player_sprite.rect.y), "time" : 800, "hit" : "fleet_bottom"})

    def boss_collision (self):
        # Blocks
        block_hit = pygame.sprite.groupcollide(self.blocks, self.boss, True, False)
        for block in block_hit:
            self.s.active_explosions.append({"pos" : (block.rect.x, block.rect.y), "time" : 500, "hit" : "block"})
            self.obstacle_explosion.play()
        # Player
        if pygame.sprite.groupcollide(self.player, self.boss, True, True):
            self.player_explosion_sound.play()
            self.s.active_explosions.append({"pos" : (self.player_sprite.rect.x, self.player_sprite.rect.y), "time" : 800, "hit" : "fleet_bottom"})
                            
    
    def collision_checks(self):
        """Check all the sprites collisions"""
        # player laser 
        if self.player:
            self.player_laser_collision() 
        # alien lasers  
        if self.alien_lasers:
            self.alien_laser_collision()
        # extra alien lasers 
        if self.extra_lasers:
            self.extra_laser_collision()
        # boss lasers
        if self.boss_lasers:
            self.boss_laser_collision()
        # alien collisions
        if self.aliens:
            self.alien_collision()
        # boss collisions
        if self.boss:
            self.boss_collision()

    def zero_lives_check(self):
        """ Check if you lost all lives"""
        if self.s.lives < 0:
            pygame.mixer.stop()
            self.player_explosion_sound.play()
            self.playing = False
            self.game_over_sound.play()
            self.curr_menu = self.game_over_menu        

    def display_scoreboard (self):
        """ Display on the top screen all scoreboard"""
        # display the current score
        self.draw_text(f'SCORE: {self.s.score:06}',  self.font_scoreboard, self.s.text_col, 80, 20)
        # display the hiscore
        self.draw_text(f'HI-SCORE: {self.s.hi_score:06}',  self.font_scoreboard, self.s.text_col, self.screen_rect.centerx, self.screen_rect.top + 20)
        if self.s.score > self.s.hi_score:
            self.s.hi_score = self.s.score
        # display the current level
        if self.s.level > 0:
            self.draw_text(f'LEVEL: {self.s.level}',  self.font_scoreboard, self.s.text_col, self.s.screen_width - 200, 20)
        # display the player life remaining
        if self.s.lives == -1: self.s.lives = 0
        self.draw_text(f'x {self.s.lives}',  self.font_scoreboard, self.s.text_col, self.s.screen_width - 40, 20)
        self.screen.blit(self.life_surf, (self.life_x,13))
        # display double shot warning
        if self.s.level == 7 and self.s.double_shoot_warning:
            self.blink_text()
            if self.blink_time > 1:
                self.s.active_explosions.append({"pos" : (self.screen_rect.centerx, 50), "time" : 50, "hit" : 'double_shoot'}) 
            if self.pause_time (10, True):
                self.s.double_shoot_warning = False

    def new_life(self):
        """Gives the player an extra life when they reach a certain score."""
        match self.s.score:
            case s if s >= 50000 and not self.s.executed_2:
                self.s.lives += 1
                self.new_life_sound.play()
                self.s.active_explosions.append({"pos" : (self.screen_rect.centerx, 50), "time" : 2000, "hit" : 'new_life'})
                self.s.executed_2 = True
            case s if s >= 100000 and not self.s.executed_3:
                self.s.lives += 1
                self.new_life_sound.play()
                self.s.active_explosions.append({"pos" : (self.screen_rect.centerx, 50), "time" : 2000, "hit" : 'new_life'})
                self.s.executed_3 = True
            case s if s >= 150000 and not self.s.executed_4:
                self.s.lives += 1
                self.new_life_sound.play()
                self.s.active_explosions.append({"pos" : (self.screen_rect.centerx, 50), "time" : 2000, "hit" : 'new_life'})
                self.s.executed_4 = True

    def pause_time(self, time, start):
        """ Take a pause before continuing
        Parameters:
        time (int) = pause time 
        start (boolean)= starts pause """
        if start:
            self.initial_time += 0.05
            if self.initial_time >= time:
                self.initial_time = 0
                return True
    
    def ship_boost_time(self, time, start):
        """ Take a pause before continuing
        Parameters:
        time (int) = pause time 
        start (boolean)= starts pause """
        if start:
            self.ship_initial_time += 0.03
            if self.ship_initial_time >= time:
                self.ship_initial_time = 0
                return True

    def level_up (self):
        """ If the alien fleet is destroyed, the level increases, 
        the fleet speed resets, the difficulty increases, and a new fleet is created. """
        if self.level_up_active:
            if not self.aliens:
                self.alien_fleet_sound.stop()
                if self.pause_time(8, True): 
                    self.s.level +=1
                    self.restart_speed()
                    self.raise_difficulty()
                    self.s.alien_direction = 1
                    self.alien_setup()
                    self.extra_sprite.execute = True
                    self.alien_fleet_sound.play(loops=-1)
                    

    def clean_scenary (self):
        """ deactivate the level up function and clean all the aliens and blocks on screen """
        self.level_up_active = False
        self.aliens.empty()
        self.alien_lasers.empty()
        self.extra_sprite.execute = False
        self.destroy_remaining_extra()
    
    
    def destroy_remaining_extra (self):
        if self.extra:
            for extra in self.extra:
                self.s.active_explosions.append({"pos" : (extra.rect.x, extra.rect.y), "time" : 300, "hit" : "extra_explosion"})
                self.extra_explosion_sound.play()
                self.extra.empty()
                self.extra_alien_sound.stop()
    
    def boss_fight(self):
        if not self.s.boss_executed:
            self.s.start_boss_update = False
            self.current_boss_loss_sprite = 0
            self.s.boss_direction = 1
            self.boss_sprite.rect = self.boss_sprite.image.get_rect(center = (self.s.screen_width / 2, -60))
            self.boss_sprite.x = float(self.boss_sprite.rect.x)
            self.boss_sprite.y = float(self.boss_sprite.rect.y)
            self.s.boss_speed = 3
            self.boss.add(self.boss_sprite)
            self.s.boss_executed = True
           
    
    def planet_animation(self):
        """ hide and show planets """
        if not self.finish_planet_animation:
            if self.s.level in (3, 6, 9, 12, 15, 18, 21) and not (self.aliens):  
                self.clean_scenary()
                if self.s.boss_warning:
                    self.s.active_explosions.append({"pos" : (self.screen_rect.centerx, 50), "time" : 3000, "hit" : 'warning'})
                    self.danger_sound.play() 
                    self.s.boss_warning = False
                self.s.wait += 0.05 
                if self.s.wait >= 8:
                # call boss fight function
                    self.boss_fight()
                    if len(self.boss) == 0:
                        self.s.wait_2 += 0.05 
                        if self.s.wait_2 > 16:
                            self.blocks.empty()
                            # boost to leave the planet
                            self.s.moving_stars = True
                            self.s.ship_thruster_on = True 
                            self.planet.execute_hide_planet = True
                            if self.pause_time(10, True):
                                # Go to beat game menu if you beat the game.
                                if self.s.level == 21:
                                    self.ship_thruster_sound.fadeout(2000)
                                    self.finish_planet_animation = True
                                    self.s.moving_stars = False
                                    self.playing = False
                                    self.curr_menu = self.beatgame_menu
                                else:
                                # boost to the next planet
                                    self.i += 1
                                    self.planet.image = self.planet.list[self.i] 
                                    self.planet.execute_show_planet = True
                                    self.finish_planet_animation = True
                                    self.s.executed_boss_animation = False
                                    self.s.boss_executed = False
                                    self.s.boss_warning = True
                                    self.s.wait = 0
                                    self.s.wait_2 = 0
                    
                                                                                        
    def redraw_blocks (self):
        if self.block_rebuild:
            self.block_count += 0.1
            if self.block_count <= 4: 
                for dots in self.blocks:
                    self.color_red = randint(0 ,255)
                    self.color_green = randint(0 ,255)
                    self.color_blue = randint(0 ,255)
                    dots.image.fill ((self.color_red, self.color_green, self.color_blue)) 
            else:
                self.create_multiple_obstacles()
                self.block_count = 0
                self.block_rebuild = False
            

    def reset_game(self):
        """Reset the game settings"""
        self.time =  0
        self.player_sprite.block_input = False
        self.hiscore_menu.hiscore_initialize()
        self.aliens.empty()
        self.alien_lasers.empty()
        self.lasers.empty()
        self.blocks.empty()
        self.extra.empty()
        self.planets.empty()
        self.player.empty()
        self.boss.empty()
        self.planets.add(self.planet)
        self.player.add(self.player_sprite)
        self.planet.rect = self.planet.image.get_rect(topleft = (0, self.s.screen_heigth))
        self.i = 0 
        self.planet.image = self.planet.list[self.i]
        self.level_up_active = False
        self.planet.execute_show_planet = True
        self.finish_initial_planet_animation = False
        self.create_obstacle_flag = True
        self.player_sprite.restart_player_location()
        self.s.initialize_dynamic_settings()
   
      
    def draw_text(self, text, font, text_col, x, y, pos = 'center'):
            """Draw text on screen
            Parameters:
            text (string) = text 
            font = font type
            text_col = font color
            x,y = width and heigh positon on screen"""
            img = font.render (text, False, text_col)
            img_rect = img.get_rect()
            if pos == 'topleft':
                img_rect.topleft = (x,y)
                self.screen.blit(img, img_rect)
            else:
                img_rect.center = (x,y)
                self.screen.blit(img, img_rect)
    
    def restart_speed(self):
        """ Restart the alien fleet speed"""
        self.s.alien_speed = 0.78

    def describe_planet(self):
        """ Show the planet name on the middle of screen"""
        match self.i:
            case 0: planet = "earth"   
            case 1: planet = "moon"
            case 2: planet = "mars"
            case 3: planet = "jupiter"
            case 4: planet = "saturn"
            case 5: planet = "uranus"
            case 6: planet = "netuno"
        self.s.active_explosions.append({"pos" : (self.screen_rect.center), "time" : 3000, "hit" : planet})   
     
    def raise_difficulty(self):
        """Increase the game's difficulty by raising the number of shots fired by the alien fleet
          as the level rises. Raise the number of player's shots starting on level 4 """
        match self.s.level:
            # EARTH
            case 1 | 2 | 3:
                self.s.alien_bullets_allowed = 1
                if not self.aliens:
                    self.finish_planet_animation = False 
            # MOON
            case 4 | 5 | 6:
                self.s.activate_extra_shot = True
                self.s.alien_speed = 0.83 # 5% increase fleet speed
                self.s.boss_speed = 3.15
                self.s.alien_bullets_allowed = 2
                self.s.extra_bullets_allowed = 1
                self.s.boss_total_hits = 12
                if not self.aliens:
                    self.finish_planet_animation = False              
            # MARS
            case 7 | 8 | 9:
                self.s.alien_speed = 0.88 # 5% increase fleet speed
                self.s.boss_speed = 3.30
                self.s.alien_bullets_allowed = 3
                self.s.extra_bullets_allowed = 2
                self.s.shoots_allowed = 2
                self.s.boss_total_hits = 20 
                if not self.aliens:
                    self.finish_planet_animation = False      
            # JUPITER
            case 10 | 11 | 12:
                self.s.alien_speed = 0.93 # 5% increase fleet speed
                self.s.boss_speed = 3.45
                self.s.alien_bullets_allowed = 4
                self.s.extra_bullets_allowed = 3
                self.s.boss_bullets_allowed = 2
                self.s.boss_total_hits = 22  
                if not self.aliens:
                    self.finish_planet_animation = False
            # SATURN
            case 13 | 14 | 15:
                self.s.alien_speed = 0.98 # 5% increase fleet speed
                self.s.boss_speed = 3.60
                self.s.alien_bullets_allowed = 5
                self.s.boss_total_hits = 25 
                if not self.aliens:
                    self.finish_planet_animation = False
            # URANUS
            case 16 | 17 | 18:
                self.s.alien_speed = 1.03 # 5% increase fleet speed
                self.s.boss_speed = 3.75
                self.s.alien_bullets_allowed = 6
                self.s.extra_shoot_interval = 800
                self.s.boss_total_hits = 30 
                if not self.aliens:
                    self.finish_planet_animation = False
            # NEPTUNE
            case 19 | 20 | 21:
                self.s.alien_speed = 1.03 # keep fleet speed
                self.s.boss_speed = 3.90
                self.s.alien_bullets_allowed = 6
                self.s.boss_bullets_allowed = 3
                self.s.boss_total_hits = 35
                if not self.aliens: 
                    self.finish_planet_animation = False
            
              
    def save_hiscore(self):
        # define a random key for the dictionary
        code = randint(1, 1000000)
        # if the dictionary key exists in loaded hiscore file get other random key 
        if str(code) in self.s.current_hiscore.keys():
            code = randint(1, 1000000)
        # create a dictionary with a random key with name and sccore of the player as values
        self.s.new_hiscore[code] = [self.s.name, self.s.score]   
        # save score on dictionary
        self.s.current_hiscore.update(self.s.new_hiscore)
        # save the hiscore file but sort first from the greater to lowest
        sorted_hiscore = dict(sorted(self.s.current_hiscore.items(), key=lambda item: item[1][1], reverse=True))
        try:
            with open (self.s.hiscore_file, "wb") as file:
                pickle.dump (sorted_hiscore, file)
        except Exception:
            pass

    
    def verify_score(self):
        lowest_hiscore = min(self.s.current_hiscore.items(), key=lambda item: item[1][1])
        key, values = lowest_hiscore
        if self.s.score > values[1]:
            self.s.current_hiscore.pop(key)
            if self.s.score > self.s.hiscore_list[0][1]:
                 self.hiscore_menu.score_color = self.main_menu.first_color
                 self.first_place_sound.play()
            else:
                self.name_entry_sound.play()
            self.curr_menu = self.hiscore_menu
        else:
            self.reset_game()
            self.curr_menu = self.main_menu
           

    def shoot_laser(self):
        """Create player laser sprite and add to the sprite group"""
        if len(self.lasers) < self.s.shoots_allowed:
            self.laser_sound.play()
            self.lasers.add(Laser(self.player_sprite.rect.center, self))

    def blink_text (self):
        self.blink_time += 0.1 
        if self.blink_time >= 2:
            self.blink_time = 0


    def check_events(self):
        """Check player input events"""
        if self.extra:
            if self.actual_time - self.s.last_extra_shoot >= self.s.extra_shoot_interval:
                self.extra_shoot()
                self.s.last_extra_shoot = self.actual_time
        if self.boss:
            if self.actual_time - self.s.last_boss_shoot >= self.s.boss_shoot_interval:
                self.boss_shoot()
                self.s.last_boss_shoot = self.actual_time

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()              
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LCTRL or event.key == pygame.K_RCTRL:
                    self.shoot_laser()
                if event.key == pygame.K_ESCAPE:
                    if self.s.game_paused == False: 
                        self.s.game_paused = True
                        pygame.mixer.pause()
                                                
    
    def check_events_paused(self):
        """ check player input events when paused """
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                 sys.exit()
            if event.type == pygame.KEYDOWN:              
                if event.key == pygame.K_ESCAPE:
                    self.playing = False
                    self.s.game_paused = False
                    self.reset_game()
                  
                if event.key == pygame.K_LCTRL or event.key == pygame.K_RCTRL:
                    self.s.game_paused = False
                    pygame.mixer.unpause()

    def pause_menu(self):
        self.check_events_paused()
        self.screen.blit(self.pause_keys, self.pause_keys_rect)
        pygame.display.update()
    


    async def game_loop(self):
        """Run all the critical functions for the game """
        while self.playing:
    
            if not self.s.game_paused:
                
                self.check_events()
                self.screen.fill('black')
                self.stars.update()
                self.player.update()
                self.lasers.update()
                self.aliens.update(self.s.alien_direction, self.s.alien_speed)
                self.alien_lasers.update()
                self.extra_lasers.update()
                self.boss_lasers.update()
                self.blocks.update()
                self.extra.update()
                self.boss.update()
                self.planets.update()
                self.actual_time = pygame.time.get_ticks()
                
                self.explosion_time()
                self.alien_shoot()
                self.extra_alien_timer()
                self.alien_position_checker()
                self.collision_checks()
                self.level_up()
                self.new_life()
                self.pause_time(self.time, self.start)
                self.planet_animation()
                self.ship_boost_time(self.ship_time, self.start_boost)
                self.zero_lives_check()
                self.display_scoreboard()
        
                self.stars.draw(self.screen)
                self.planets.draw(self.screen)
                self.player.draw (self.screen)
                self.lasers.draw(self.screen)
                self.aliens.draw(self.screen)
                self.alien_lasers.draw(self.screen)
                self.extra_lasers.draw(self.screen)
                self.boss_lasers.draw(self.screen)
                self.blocks.draw(self.screen)
                self.extra.draw(self.screen)
                self.boss.draw(self.screen)
                self.draw_explosion()
                self.redraw_blocks()
                #self.crt.draw()
                pygame.display.flip()
                self.dt = self.clock.tick(60)
                await asyncio.sleep(0)
                
            else:
                self.pause_menu()
                await asyncio.sleep(0)
               

async def main():   
    pygame.mixer.pre_init (44100, -16, 2, 4096)
    pygame.init()
    pygame.mixer.set_num_channels(32)
    if sys.platform == "emscripten":
        platform.window.canvas.style.imageRendering = "pixelated"
        platform.document.body.style.background = "#000000"
    invaders = Game()
    while invaders.running:
        pygame.mouse.set_visible(False)
        await invaders.curr_menu.display_menu()
        await invaders.game_loop()
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())   
        
        
    