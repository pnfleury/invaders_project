import pygame, json

class SpriteSheet():
    def __init__(self, filename, game):
        self.game = game
        self.filename = filename
        self.sprite_sheet = pygame.image.load(self.game.resource_path(filename)).convert_alpha()
        self.meta_data = self.game.resource_path(self.filename.replace('png', 'json'))
        with open(self.meta_data) as f:
            self.data = json.load(f)
        f.close()

    def get_sprite(self, x, y, w, h):
        sprite = pygame.Surface((w, h)).convert_alpha()
        sprite.set_colorkey((0,0,0))
        sprite.blit(self.sprite_sheet, (0,0), (x, y, w, h))
        return sprite

    def parse_sprite(self, name):
        sprite = self.data['frames'][name]['frame']
        x, y, w, h = sprite["x"], sprite["y"], sprite["w"], sprite["h"]
        image = self.get_sprite(x, y, w, h)
        return image

           